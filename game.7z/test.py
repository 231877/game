import pygame, random, math

pygame.init()
pygame.joystick.init()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]
joysticks[0].init()

size = width, height = 600, 400
stack, effect, camera = [], [], {'x': 0, 'y': 0, 'width': 800, 'height': 600}

def distance(x1, y1, x2, y2): return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
def draw(image, x, y): screen.blit(image, (x, y))

class Object:
	def __init__(self, x, y, image=None, xoffset=0, yoffset=0):
		self.x, self.y, self.image = x, y, image
		self.type = None
		self.image_speed = .1
		if self.image is not None:
			if type(self.image) == list:
				self.image_index, self.image_speed = 0, .1
				self.rect = self.image[0].get_rect()
			else:
				self.rect = self.image.get_rect()
			self.move(self.x, self.y)
		else: self.rect = None
		self.xoffset, self.yoffset = xoffset, yoffset
		self.deform = 0
	def set(self, image):
		self.image = image
		self.rect = self.image.get_rect()
		self.move(self.x, self.y)
	def move(self, x, y): self.rect[0], self.rect[1] = x, y
	def draw(self): 
		if self.deform > 0:
			if type(self.image) == list:
				self.dimage = pygame.transform.scale(self.image[int(self.image_index)], (self.rect[2] + int(self.rect[2] * .1 * self.deform), self.rect[3] + int(self.rect[3] * .15 * self.deform)))
				self.image_index += self.image_speed
				if self.image_index > len(self.image): self.image_index = 0
				if self.image_index < 0: self.image_index = len(self.image) - 1
			else: self.dimage = pygame.transform.scale(self.image, (self.rect[2] + int(self.rect[2] * .1 * self.deform), self.rect[3] + int(self.rect[3] * .15 * self.deform)))
			screen.blit(self.dimage, (self.rect[0] - self.xoffset - camera['x'] - (self.rect[2] * .1 * self.deform) * .5, self.rect[1] - self.yoffset - camera['y'] - (self.rect[3] * .15 * self.deform)))
			self.deform -= .1
		else:
			if type(self.image) == list:
				screen.blit(self.image[int(self.image_index)], (self.rect[0] - self.xoffset - camera['x'], self.rect[1] - self.yoffset - camera['y']))
				self.image_index += self.image_speed
				if self.image_index > len(self.image): self.image_index = 0
			else: screen.blit(self.image, (self.rect[0] - self.xoffset - camera['x'], self.rect[1] - self.yoffset - camera['y']))
class Table(Object):
	def __init__(self, x, y, xoffset=0, yoffset=0):
		self.x, self.y, self.image = x, y, pygame.image.load("table.png")
		self.rect = self.image.get_rect()
		self.rect[0], self.rect[1] = x, y
		self.xoffset, self.yoffset = xoffset, yoffset
		self.deform = 0
	def show(self, text, color=(0, 0, 0)):
		bitmap = font.render(text, True, color)
		screen.blit(bitmap, (self.x - self.xoffset - camera['x'], self.y - 25 - self.yoffset - camera['y']))

class Bullet(Object):
	def __init__(self, x, y, image=None, xoffset=0, yoffset=0, dir=0, speed=4, friendly=False, timeout=60):
		self.x, self.y, self.image = x, y, image
		self.type = "bullet"
		if self.image is not None:
			if type(self.image) == list:
				self.image_index, self.image_speed = 0, .1
				self.rect = self.image[0].get_rect()
			else:
				self.rect = self.image.get_rect()
			self.move(self.x, self.y)
		else: self.rect = None
		self.xoffset, self.yoffset = xoffset, yoffset
		self.dir, self.speed = dir, speed
		if type(self.image) == list:
			pass
		else:
			self.image = pygame.transform.rotate(self.image, self.dir)
		self.friendly = friendly
		self.timeout = timeout
		self.deform = 0
	def update(self):
		if self.timeout > 0:
			self.x += math.cos(math.radians(self.dir)) * self.speed
			self.y -= math.sin(math.radians(self.dir)) * self.speed

			for i in range(len(stack)):
				if stack[i].type == "boss" and self.friendly:
					if distance(self.x, self.y, stack[i].x, stack[i].y - 50) <= 70:
						effect.append(Object(self.x, self.y, image=spr_fire, xoffset=32, yoffset=32))
						if not stack[i].state:
							stack[i].hp -= 1
							stack[i].deform = 1
						return 1
				if stack[i].type == "player" and not self.friendly:
					if distance(self.x, self.y, stack[i].x, stack[i].y - 40) <= 40:
						effect.append(Object(self.x, self.y, image=spr_fire, xoffset=32, yoffset=32))
						stack[i].deform = 1
						return 1
			self.move(self.x, self.y)
			self.timeout -= 1
		else: return 1
		return 0

player_img = {
	'move': [pygame.image.load("player/1.png"), pygame.image.load("player/2.png"), pygame.image.load("player/3.png"), pygame.image.load("player/4.png")],
	'attack_default': [pygame.image.load("player/attack_default/1.png"), pygame.image.load("player/attack_default/2.png"), pygame.image.load("player/attack_default/3.png")],
	'attack_default2': [pygame.image.load("player/attack_default/4.png"), pygame.image.load("player/attack_default/5.png"), pygame.image.load("player/attack_default/6.png"), pygame.image.load("player/attack_default/7.png"), pygame.image.load("player/attack_default/8.png")]
}

player = Object(400, 450, image=player_img['move'], xoffset=50, yoffset=90)
player.hspd, player.vspd, player.g_speed = 0, 0, [25, 25]
player.type, player.xscale = 1, 1
player.image_speed = 2
player.type = "player"
player.state = 0
stack.append(player)


boss_img = {
	'default': pygame.image.load('boss1.png'),
	'afk': [pygame.image.load("boss1/afk1.png"), pygame.image.load("boss1/afk2.png"), pygame.image.load("boss1/afk3.png")],
	'up': [pygame.image.load("boss1/up1.png"), pygame.image.load("boss1/up2.png"), pygame.image.load("boss1/up3.png"), pygame.image.load("boss1/up4.png")]
}
boss = Object(400, 350, image=boss_img['default'], xoffset=125, yoffset=210)
boss.type = "boss"
boss.boss_type = 1
boss.dir = 0
boss.g_speed = [5, 50]
boss.state = 0
boss.timer = 300
boss.d_damage = 0

boss.hp = 50

back = pygame.image.load("level1.png")
handle = pygame.image.load("level1_pre.png")


health = pygame.image.load("health.png")

stack.append(boss)

empty = pygame.image.load('empty.png')
spr_fire = [pygame.image.load("fire/1.png"), pygame.image.load("fire/2.png"), pygame.image.load("fire/3.png")]
bullet_list = pygame.image.load('bullet_list.png')

def add_bullet(x, y, dir, speed=4, friendly=False, image=spr_fire, timeout=200):
	stack.append(Bullet(x, y, image=image, xoffset=32, yoffset=32, dir=dir, speed=speed, friendly=friendly, timeout=timeout))

grass = []
for i in range(10):
	grass.append(Object(boss.x - 200 + random.randint(0, 400), boss.y - 100 + random.randint(0, 200), image=pygame.image.load("grass.png"), xoffset=30, yoffset=40))
	stack.append(grass[i])

stone = Object(130, 180, image=pygame.image.load("stone.png"), xoffset=50, yoffset=80)
stack.append(stone)


font = pygame.font.Font(None, 24)

def movement(): # player move:
	xaxis, yaxis, fr, speed = joysticks[0].get_axis(0), joysticks[0].get_axis(1), .2, 5
	
	#player.hspd = xaxis * speed
	#player.vspd = yaxis * speed
	player.hspd += min(max((xaxis * speed - player.hspd) * fr, -speed), speed)
	player.vspd += min(max((yaxis * speed - player.vspd) * fr, -speed), speed)



	val = player.xscale

	if xaxis != 0:
		if xaxis < 0: val = -1
		else: val = 1

	if player.xscale != val:
		player.xscale = val
		for key in player_img:
			for i in range(len(player_img[key])):
				player_img[key][i] = pygame.transform.flip(player_img[key][i], 1, 0)
	player.x += player.hspd
	player.y += player.vspd
	player.move(player.x, player.y)
	if not player.state:
		if xaxis != 0 or yaxis != 0:
			player.image_speed = .15
		else:
			player.image_speed = 0
			player.image_index = 0

	if player.state == 1:
		if player.image_index >= len(player.image) - player.image_speed:
			add_bullet(player.x - 20 + random.randint(0, 40), player.y - player.yoffset * .25 - 5 + random.randint(0, 10), 0, speed=0, friendly=True, timeout=1)
			player.state = 0
			player.image = player_img['move']
			player.image_index = 0

	

	# shot:
	"""
	sxaxis, syaxis = joysticks[0].get_axis(2), joysticks[0].get_axis(3)
	if (abs(sxaxis) > .75 or abs(syaxis) > .75) and player.g_speed[0] >= player.g_speed[1]:
		add_bullet(player.x - 20, player.y - player.yoffset * .25, math.degrees(math.pi + math.atan2(syaxis, -sxaxis)), speed=9, friendly=True)
		player.g_speed[0] = 0
	"""
	if joysticks[0].get_button(0) and player.g_speed[0] >= player.g_speed[1]:
		if not player.state:
			player.state = 1
			l = ['attack_default', 'attack_default2']
			player.image = player_img[l[random.randint(0, len(l) - 1)]]
			player.image_index = 0
			player.image_speed = .15
			player.g_speed[0] = 0
	if player.g_speed[0] < player.g_speed[1]: player.g_speed[0] += .6
	#	player.deform = 1
	
def gui():
	hp = int(math.ceil((boss.hp + 20) / 20) - 1)
	for i in range(hp):
		draw(health, 300 - (hp * 50) + 100 * i, 10)

	#draw(health, 10, 10)

screen = pygame.display.set_mode(size)
pygame.display.set_caption("Game")

clock = pygame.time.Clock()

exit = False
while not exit:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit = True
	

	movement()

	screen.fill((50, 104, 59))

	draw(back, -camera['x'], -camera['y'])

	for i in range(len(stack)):
		if stack[i].type == "bullet":
			if stack[i].update():
				del stack[i]
				break
	arr = stack + effect
	for i in range(len(arr)):
		arr[i].draw()
		if arr[i].type == 2:
			arr[i].show("Hello world!")
		elif arr[i].type == 3:
			arr[i].show("World!")
		elif arr[i].type == "boss":
			if arr[i].boss_type == 1:
				if arr[i].g_speed[0] < arr[i].g_speed[1]: arr[i].g_speed[0] += 1
				if arr[i].image == boss_img['default']:
					if arr[i].state == 1:
						arr[i].g_speed[1] = 10
						arr[i].dir = math.degrees(math.atan2(arr[i].y - (player.y - player.yoffset * .25), player.x - arr[i].x))
						if arr[i].g_speed[0] >= arr[i].g_speed[1]:
							arr[i].deform = .5
							add_bullet(arr[i].x + math.cos(math.radians(arr[i].dir)) * 50, arr[i].y - math.sin(math.radians(arr[i].dir)) * 10 - 10, arr[i].dir - 10 + random.randint(0, 20), speed=9, image=bullet_list)
							arr[i].g_speed[0] = 0
						
						
					elif arr[i].state == 2:
						arr[i].g_speed[1] = 50
						if arr[i].g_speed[0] >= arr[i].g_speed[1]:
							arr[i].deform = 2
							if arr[i].d_damage % 2:
								for j in range(360 / 40):
									add_bullet(arr[i].x + math.cos(math.radians(j * 40)) * 50, arr[i].y - math.sin(math.radians(j * 40)) * 10 - 10, j * 40 - 5 + random.randint(0, 10), speed=7, image=bullet_list)
							else:
								for j in range(360 / 40):
									add_bullet(arr[i].x + math.cos(math.radians(j * 40 + 20)) * 50, arr[i].y - math.sin(math.radians(j * 40 + 20)) * 10 - 10, j * 40 + 15 + random.randint(0, 10), speed=7, image=bullet_list)	
							arr[i].d_damage += 1
							arr[i].g_speed[0] = 0
				if arr[i].image != boss_img['up']:
					if arr[i].timer > 0: arr[i].timer -= 1
					else:
						val = random.randint(0, 2)
						while val == arr[i].state:
							val = random.randint(0, 2)
						arr[i].state = val
						if not val:
							arr[i].image = boss_img['up']
							arr[i].image_speed = -.05
							arr[i].image_index = len(boss_img['up']) - 1
						else:
							if arr[i].image == boss_img['afk']:
								arr[i].image = boss_img['up']
							arr[i].image_index = 0
							arr[i].image_speed = .05

							#arr[i].image = boss_img['afk']
						#else: arr[i].image = boss_img['up']
						
						arr[i].timer = 300 + random.randint(0, 200) * (val > 0)
				else:
					if not arr[i].state:
						if arr[i].image_index <= abs(arr[i].image_speed):
							arr[i].image_index = 0
							arr[i].image_speed = .1
							arr[i].image = boss_img['afk']
					else:
						if arr[i].image_index >= len(arr[i].image) - arr[i].image_speed:
							arr[i].image_index = 0
							arr[i].image = boss_img['default']

	stack = sorted(stack, key=lambda x: x.y)
	
	for i in range(len(effect)):
		if effect[i].image_index >= len(effect[i].image) - effect[i].image_speed:
			del effect[i]
			break

	draw(handle, -camera['x'], -camera['y'])

	camera['x'] += ((player.x - camera['x']) - 300) * .05
	camera['y'] += (((player.y - player.yoffset * .5) - camera['y']) - 200) * .05
	camera['x'] = min(max(camera['x'], 0), camera['width'] - 600)
	camera['y'] = min(max(camera['y'], 0), camera['height'] - 400)




	# gui:
	gui()

	pygame.display.flip()

	clock.tick(60)

pygame.quit()


